<?php 
include('lock.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //echo "<i>hello</i>";
$url = $_POST['event_id'] ;
mysqli_query($connection, "INSERT INTO register_event(event_id, username) VALUES
		('$url','$login_session')");
		
 
  //for email
  
  $sql="SELECT email FROM users WHERE username='$login_session'";
$result=mysqli_query($connection, $sql);
$row=mysqli_fetch_array($result);
//$active=$row['active'];
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1)
{
$admin_email = $row['email'];
}

  $subject = 'REGISTRATION CONFIRMATION';
  $comment = 'You have successfully registered for this event';
   mail($admin_email, "$subject", $comment, "From:" . $email);
}
?>