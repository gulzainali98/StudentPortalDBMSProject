<?php
include('config.php');
session_start();
$user_check=$_SESSION['myusername'];

$ses_sql=mysqli_query($connection, "select username from users where username='$user_check' ");

$row=mysqli_fetch_array($ses_sql);

$login_session=$row['username'];

if(!isset($login_session))
{
	echo "lalal";
//header("Location: login.php");
}
?>