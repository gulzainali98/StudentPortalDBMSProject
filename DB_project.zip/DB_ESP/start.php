<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Welcome to Nust Portal- log in and sign up</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
  
  <![endif]-->
  <style>
  
  #signupmodal {
top:5%;
right:50%;
outline: none;
}
#signupmodal .modal-dialog  {width:50%;}
body {
    background-image: url("mainoffice.jpg");
    background-repeat: no-repeat;
	background-size: cover;
}

#loginmodal {
top:5%;
left:50%;
outline: none;
}
#loginmodal .modal-dialog,modal-content  {width:50%;
                            height:80%}
#myModal .modal-dialog,modal-content  {width:50%;
                            height:80%}

.space{
    margin-bottom:5px;

}
  </style>

</head>

<body>


	

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation">
        <div class="container topnav">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand topnav" href="#">NUST PORTAL</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
				<li ><a data-toggle="modal" data-target="#loginmodal">LOG IN</a></li>
                    
                   <li ><a data-toggle="modal" data-target="#signupmodal">SIGN UP</a></li>
                    
					<li ><a data-toggle="modal" data-target="#myModal">ABOUT</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>


    <!-- Header -->
    <a name="about"></a>
    <div class="intro-header">
        <div class="container">

            <div class="row">
                <div class="col-lg-12">
                    <div class="intro-message">
                        <h1>NUST PORTAL</h1>
						
                        
                        <hr class="intro-divider">
                        <ul class="list-inline intro-social-buttons">
                            <li>
                                <a data-toggle="modal" data-target="#loginmodal" class="btn btn-default btn-lg"><i class="glyphicon glyphicon-star"></i> <span class="network-name">LOG IN</span></a>
                            </li>
                            <li>
                                <a data-toggle="modal" data-target="#signupmodal" class="btn btn-primary btn-lg"><i class="glyphicon glyphicon-star-empty"></i> <span class="network-name">SIGN UP</span></a>
                            </li>
                           
                        </ul>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.intro-header -->

         <!--MODALS-->
<!--FOR MODAL-->
	<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="myModal">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">About</h4>
	</div>
	<div class="modal-body">
	Nust portal 
	
	</div>
	<div class="modal-footer">
	<button class="btn btn-success" data-dismiss="modal">Close</button>
	
	
	 </div>
	 </div>
	
	 </div>
	 </div>
	 
	</div>
	<!--LOG IN MODAL START-->
	
		
		<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="loginmodal">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">Log in</h4>
	</div>
	<div class="modal-body" style = "width:500px">
	<!--form will be placed here-->
	<form class="form-inline " action=login.php method=post>
	
	
	<!-- element of forms are included in form div-->
	<!--Username-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-user"></span> 
	</div>
	<input type="text" class="form-control" name="username" placeholder="Username"/>
	</div>
	</div>
	</br>
	<!--Password-->
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-lock"></span> 
	</div>
	<input type="password" class="form-control" name="password" placeholder="Password"/>
	</div>
	</div>
	
<!--Button-->	
	
	<div style = "width:300px" class="form-group space">
	
	<input type="submit" value="Log in" class="btn btn-danger" name="Register"/>
	</div>
	</form>
	</div>
	
	<!-- form end-->
	</div>
	
	 </div>
	
	 </div>
	 </div>
	 </div>

	<!-- LOG IN MODAL END-->
	<!--SIGN UP MODAL-->
	
		<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="signupmodal">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">Sign Up</h4>
	</div>
	<div class="modal-body" style = "width:500px">
	<!--form will be placed here-->
	<form class="form-inline " action=signup.php method=post>
	
	
	<!-- element of forms are included in form div-->
	<!--Username-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-user"></span> 
	</div>
	<input type="text" class="form-control" name="username" placeholder="Username"/>
	</div>
	</div>
	</br>
	<!--Password-->
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-lock"></span> 
	</div>
	
	<input type="password" class="form-control" name="password" placeholder="Password"/>
	</div>
	</div>
	<!--First Name-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-user"></span> 
	</div>
	<input type="text" class="form-control" name="fname" placeholder="First Name"/>
	</div>
	</div>
	<!--Last Name-->
	
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-user"></span> 
	</div>
	<input type="text" class="form-control" name="lname" placeholder="Last Name"/>
	</div>
	</div>
	</br>
	<!--Email-->
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-envelope"></span> 
	</div>
	<input type="email" class="form-control" name="email" placeholder="Email"/>
	</div>
	</div>
	</br>
	<!--Age-->
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-calender"></span> 
	</div>
	<input type="number" class="form-control" name="age" placeholder="Age"/>
	</div>
	</div>
	<!--Gender-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-envelope"></span> 
	</div>
	<select name="gender" class="form-control" >
  <option value="male">Male</option>
  <option value="female">Female</option>

  <option value="other">Other</option>
</select>
	</div>
	</div>
</br>
	<!--Category-->
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-briefcase"></span> 
	</div>
	<select name="category" class="form-control" >
  <option value="student">Student</option>
  <option value="faculty">Faculty</option>

  <option value="other">Other</option>
</select>
	</div>
	</div>
	</br>
<!--Button-->	
	
	<div style = "width:300px" class="form-group space">
	
	<input type="submit" value="Sign up" class="btn btn-danger" name="Register"/>
	</div>
	
	</form>
	</div>
	
	<!-- form end-->
	</div>
	<!--<div class="modal-footer">
	<button class="btn btn-danger" data-dismiss="modal" style="float:right">Close</button>
	
	
	 </div>
	 -->
	 </div>
	
	 </div>
	 </div>
	 </div>

	
	<!--SIGN UP MODAL END-->


		 

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                    <p class="copyright text-muted small">Welcome to Nust Portal </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
