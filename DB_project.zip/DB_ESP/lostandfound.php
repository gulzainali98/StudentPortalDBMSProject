<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Untitled Form</title>
<link rel="stylesheet" type="text/css" href="view.css" media="all">
<script type="text/javascript" src="view.js"></script>

</head>
<body id="main_body" >
	
	<img id="top" src="top.png" alt="">
	<div id="form_container">
	
		<h1><a>Nust Portal</a></h1>
		<form id="form_1086753" class="appnitro" enctype="multipart/form-data" method="post" action="insert.php">
					<div class="form_description">
			<h2>Lost And Found Form</h2>
			<p>Enter Found or Lost item description.</p>
		</div>						
			<ul >
			
					<li id="li_1" >
		<label class="description" for="element_1">Location </label>
		<div>
			<input id="element_1" name="location" class="element text large" type="text" maxlength="255" value=""/> 
		</div><p class="guidelines" id="guide_1"><small>enter location where you found the item .</small></p> 
		</li>		<li id="li_2" >
		<label class="description" for="element_2">Description of item </label>
		<div>
			<textarea id="element_2" name="description" class="element textarea medium"></textarea> 
		</div> 
		</li>		<li id="li_3" >
		<label class="description" for="element_3">Image of Item(Optional) </label>
		<div>
			<input id="element_3" name="Image" class="element file" type="file"/> 
		</div> <p class="guidelines" id="guide_3"><small>Upload image of item</small></p> 
		</li>
			
					<li class="buttons">
			    <input type="hidden" name="form_id" value="1086753" />
			    
				<input id="saveForm" class="button_text" type="submit" name="submit" value="Submit" />
		</li>
			</ul>
		</form>	
		
	</div>
	<img id="bottom" src="bottom.png" alt="">
	</body>
</html>