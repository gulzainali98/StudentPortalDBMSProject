<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
include('lock.php');
?>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
<title>Events</title>
<style>
body {
    background-image: url("test4.jpg");
    background-repeat: no-repeat;
	background-size: cover;
}
</style>
 
 <link href="css/bootstrap.min.css" rel="stylesheet">

</head>
	
    <body>
	
	<!--nav bar added --->
	<div class="navbar navbar-default navbar-fixed-top topnav" role = "navigation">
	<div class="container">
	<div class="navbar-header">
	<a href="" class="navbar-brand">NUST PORTAL</a><!--for logo area-->
	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
	<span class="sr-only">Toggle navigation</span>
	<!-- for three straight lines on button-->
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	
	</button>
	</div>
	<div class="collapse navbar-collapse"><!--on changing size, coverts into dropdown type-->
	<ul class="nav navbar-nav navbar-right">
	<!-- add class active in li to highlight the page we are on-->

	<li><a href="eventlist.php">ALL EVENTS</a></li>
	<li ><a href="eventfeed.php">MY EVENTS</a></li>
	<li><a href="addevent.php"> ADD EVENT</a></li>
	<li ><a href="logout.php">LOG OUT</a></li>
	
	</ul>
	

		</div>
	</div>
	</div>
	
	
	<!--FOR MODAL about-->
	<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="myModal">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">About</h4>
	</div>
	<div class="modal-body">
	In this section you can add an event along with its description</br>
	Added event will be visible to all in "ALL EVENTS" section</br>
	</div>
	<div class="modal-footer">
	<button class="btn btn-primary" data-dismiss="modal">Close</button>
	
	
	 </div>
	 </div>
	
	 </div>
	 </div>
	 
	</div>
	<!--FOR MODAL set price-->
	<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="priceModal">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">Set Price</h4>
	</div>

	<form class="form-horizontal" action=addevent.php method=post>
	<div style = "width:300px" class="form-group modal-body">
	<label for="m_price">Member Price</label>
	<input type="number" class="form-control" name="m_price"/>
	</div>
	<div style = "width:300px" class="form-group modal-body">
	<label for="nm_price">Non-Member Price</label>
	<input type="number" class="form-control" name="nm_price"/>
	</div>
	
	<div style = "width:300px" class="form-group modal-footer">
	<input type="submit" class="btn btn-success" data-dismiss="modal">Save</button>
	
	
	 </div>
	<!-- </form> -->
	 </div>
	
	 </div>
	 </div>
	 
	</div>


	 
	 <!--put verything in container for html-->
	
	<div class="container jumbotron">
	
	<form class="form-horizontal" action=addevent.php method=post>
	
	
	<!-- element of forms are included in form div-->
	<div style = "width:300px" class="form-group" size="50">
	<label for="name">Event name</label>
	<input type="text" class="form-control" name="name"/>
	</div>
	<div style = "width:300px" class="form-group">
	<label for="organizer">Organizing society</label>
	<input type="text" class="form-control" name="organizer"/>
	</div>
	
	<div style = "width:300px" class="form-group">
	<label for="venue">Venue</label>
	<input type="text" class="form-control" name="venue"/>
	</div>
	
	<div style = "width:300px" class="form-group">
	<label for="description">Description</label>
	<input type="text" class="form-control" name="description"/>
	</div>
	
	<div style = "width:300px" class="form-group">
	<label for="date">Date Created:</label>
	<input type="date" class="form-control" name="date"/>
	</div>
	
	<div style = "width:300px" class="form-group">
	
	<input type="button" class="btn btn-default" value ="Set Price" name="price" data-toggle="modal" data-target="#priceModal"/>
	</div>
	
	<div style = "width:300px" class="form-group">
	
	<input type="submit" value="Create" class="btn btn-success" name="Create"/>
	</div>
	</form>
	</form>
	
	</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
 
    <?php
	
	if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$name = $_POST['name'];
	$organizer = $_POST['organizer'];
	$venue = $_POST['venue'];
	$description = $_POST['description'];
	$date = $_POST['date'];
	$m_price = $_POST['m_price'];
	$nm_price = $_POST['nm_price'];
	
	mysqli_query($connection, "INSERT INTO event (username, name, description, venue, organizer, date_created,m_price,nm_price ) VALUES
		('$login_session', '$name','$description', '$venue', '$organizer', '$date','$m_price','$nm_price')");
}
	?>
		
    </body>
</html>