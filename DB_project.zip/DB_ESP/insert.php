<?php
/* ----------------------------- Code for Dabase ----------------------------- */
echo '<p>hello</p>';  
  // Database Properties
    $dbhost = '127.9.145.130';
    $dbuser = 'adminqzM2lPc';
    $dbpass = 'Bh5Y2QNXQCrS';
    $db = 'nustportal';


    // Connect Database
    $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db) or die (mysql_error());
  //  mysql_select_db($db, $conn) or die(mysql_error());
/* ----------------------------- Code for Dabase ----------------------------- */

    if (isset ($_POST["location"]) || isset ($_POST["description"]))
    {
        $location = $_POST["location"];
        $description = $_POST["description"];
    }
  
    // Insert value into DB
    $sql = "insert into nustportal.item (username,location,description) VALUES ('lagulzain','$location','$description');";
    $res = mysqli_query($conn,$sql) or die(mysql_error());

    mysqli_close($conn);

    if ($res)
    {
        echo "success";
    }
    else
    {
        echo "faild";
    }
?>