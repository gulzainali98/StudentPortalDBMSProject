
	

<?php
include("config.php");
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST")
{
// username and password sent from Form
$myusername=addslashes($_POST['username']);
$mypassword=addslashes($_POST['password']);

$sql="SELECT username FROM users WHERE username='$myusername' and password='$mypassword'";
$result=mysqli_query($connection, $sql);
$row=mysqli_fetch_array($result);
//$active=$row['active'];
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count==1)
{

$_SESSION['myusername']=$row['username'];

header("location: homepage.php");
//echo "logged in";
}
else
{
$error="Your Login Name or Password is invalid";
echo $error;
}
}
?>

	