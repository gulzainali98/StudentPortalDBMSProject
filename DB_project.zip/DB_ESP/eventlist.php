<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Nust Portal - Event</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
<title>NUST PORTAL</title>
<style>

body {
    background-image: url("test4.jpg");
    background-repeat: repeat;
	background-size: cover;
}
.navbar-right li a {
  text-align: right;
}
ul.nav a:hover { background-color: #04B4AE !important; }



</style>
<link href="css/bootstrap.min.css" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

	<!--nav bar added --->
	<div class="navbar navbar-default navbar-fixed-top topnav" role = "navigation">
	<div class="container">
	<div class="navbar-header">
	<a href="" class="navbar-brand">NUST PORTAL</a><!--for logo area-->
	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
	<span class="sr-only">Toggle navigation</span>
	<!-- for three straight lines on button-->
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	
	</button>
	</div>
	<div class="collapse navbar-collapse"><!--on changing size, coverts into dropdown type-->
	<ul class="nav navbar-nav navbar-right">
	<!-- add class active in li to highlight the page we are on-->

	<li><a href="eventlist.php">ALL EVENTS</a></li>
	<li ><a href="eventfeed.php">MY EVENTS</a></li>
	<li><a href="addevent.php"> ADD EVENT</a></li>
	<li ><a href="logout.php">LOG OUT</a></li>
	
	</ul>
	

		</div>
	</div>
	</div>
	


	<div class="container">
	<?php
include('lock.php');
?>
<?php




$query = "SELECT * FROM event";


$comments = mysqli_query($connection, $query);


echo "<h1>EVENTS</h1>";
$array = array();
$id_array = array();
$i = 0;


while($row = mysqli_fetch_assoc($comments))
{
	
$array[]= $row;
  $id_array[$i] = $row['event_id'];

 $event_id = $row['event_id'];
  $name = $row['name'];
   $organizer = $row['organizer'];
  $description = $row['description'];
  $date = $row['date_created'];
  $venue = $row['venue'];
   $m_price = $row['m_price'];
    $nm_price = $row['nm_price'];
  
  

 
  
  echo " 
 
  
  <div id = 'element'.$i class='jumbotron' style='margin:30px 0px;'>
  
	
	
	
     
      <h4> $name<br />
      Organizer : $organizer<br />
	  
      venue: $venue<br />
      Description: $description<br />
      Date created: $date</br>
	  Member price: $m_price</br>
	  Non-member price: $nm_price</br>
	  </h4>
	  <button type='submit' id = '$i' value='Sign up'  class='btn btn-primary'  name='Register' onclick='ajax_post($i)'/>Register</br>
	 
	  
	 
	 
    </div>
  ";
   $i++;
  
}


?>

	
	
	</div>
	<div id="registermodal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Confirm Registration</h4>
            </div>
            <div class="modal-body">
                <p>Do you want to register for this event?</p>
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary"  onclick="query()" data-dismiss="modal" data-toggle="modal" data-target="#confirmation">Register</button>
            </div>
        </div>
    </div>
</div>


<!-- MODAL CONFIRMATION-->
<div class="modal fade" id="confirmation">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title">Registration</h4>
      </div>
      <div class="modal-body">
        <p>You have successfully registered for this event</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
       
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
    

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
<script type="text/javascript">

 
var id_a = <?php echo json_encode($id_array); ?>
/*$('#button').click(function(){
	
	register();
   
	
});*/


function ajax_post(x){
	var name = id_a[x];
	var dataString = 'event_id='+ name;
    $.ajax({
type : "POST",
url: "/register_event.php",
data: dataString,
cache: false,
success: function(result){
$('#confirmation').modal("show");
}
});
}

   
</script>

</body>
</html>