<?php     
    include 'Config.php';

    $username = $_POST['username'];
    $password = $_POST['password'];
	 $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
	 $age = $_POST['age'];
    $gender = $_POST['gender'];
	 $email = $_POST['email'];
    $category = $_POST['category'];
    //$ip = $_SERVER['REMOTE_ADDR'];

    $result = mysqli_num_rows(mysqli_query($connection, "SELECT * FROM users WHERE username = '$username'"));

    if($result == 1)
    {
        echo "The username you have chosen already exists!";
    }
    else
    {
        mysqli_query($connection, "INSERT INTO users (username, password, email, category, firstname, lastname, age, gender ) VALUES
		('$username', '$password','$email','$category', '$firstname', '$lastname', '$age', '$gender')");
        echo "<p>Congratulations! You have successfully registered! </p> 
        <p>Click <a href = \"Login.php\">here</a> to login.</p>";

    }
?>