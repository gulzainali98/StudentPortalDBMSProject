<?php 
include('lock.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $sentid=$_POST['edit_id'] ;

}
?>