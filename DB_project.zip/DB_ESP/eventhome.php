<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<?php
include('lock.php');
?>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Nust Portal - Event</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/landing-page.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	
<title>NUST PORTAL</title>
<style>
 
#addevent {
top:5%;
right:50%;
outline: none;
}
#addevent .modal-dialog  {width:50%;}
body {
    background-image: url("test4.jpg");
    background-repeat: no-repeat;
	background-size: cover;
}


.space{
    margin-bottom:10px;

}

.navbar-right li a {
  text-align: right;
}
ul.nav a:hover { background-color: #04B4AE !important; }


</style>
 
 

</head>
	
    <body>
	
	<div class="navbar navbar-default navbar-fixed-top topnav" role = "navigation">
	<div class="container">
	<div class="navbar-header">
	<a href="" class="navbar-brand">NUST PORTAL</a><!--for logo area-->
	<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
	<span class="sr-only">Toggle navigation</span>
	<!-- for three straight lines on button-->
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	
	</button>
	</div>
	<div class="collapse navbar-collapse"><!--on changing size, coverts into dropdown type-->
	<ul class="nav navbar-nav navbar-right">
	<!-- add class active in li to highlight the page we are on-->
	<li ><a data-toggle="modal" data-target="#addevent">ADD EVENT</a></li>
	<li><a href="eventlist.php">ALL EVENTS</a></li>
	<li ><a href="eventfeed.php">MY EVENTS</a></li>
	
	<li ><a href="logout.php">LOG OUT</a></li>
	
	</ul>
	

		</div>
	</div>
	</div>

	

	
	<!--SIGN UP MODAL-->
	
		<div class="container">
	<!-- modal has these components. A dialog, content(then body, footer), header-->
     <div class="modal" id="addevent">
	 <div class="modal-dialog">
	 <div class="modal-content">
	<div class="modal-header">
	<button class="close" data-dismiss="modal">x</button>
	<h4 class="modal-title">Add Event</h4>
	</div>
	<div class="modal-body" style = "width:500px">
	<!--form will be placed here-->
	<form class="form-inline " action=eventhome.php method=post>
	
	
	<!-- element of forms are included in form div-->
	<!--- EVENT NAME-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-star"></span> 
	</div>
	<input type="text" class="form-control" name="name" placeholder="Event Name"/>
	</div>
	</div>
	<!--- ORGANIZING SOCIETY-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-cog"></span> 
	</div>
	<input type="text" class="form-control" name="organizer" placeholder="Organizing Society"/>
	</div>
	</div>
	<!--- VENUE-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-home"></span> 
	</div>
	<input type="text" class="form-control" name="venue" placeholder="VENUE"/>
	</div>
	</div>
	<!--- DESCRIPTION-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-pencil"></span> 
	</div>
	<input type="text" class="form-control" name="description" placeholder="Description"/>
	</div>
	</div>
	<!--- DATE-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-calendar"></span> 
	</div>
	<input type="date" class="form-control" name="date" placeholder="Date"/>
	</div>
	</div>
	<!--- NPRICE-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-certificate"></span> 
	</div>
	<input type="number" class="form-control" name="date" placeholder="Member price-optional"/>
	</div>
	</div>
	<!--- NMPRICE-->
	</br>
	<div style = "width:300px" class="form-group space">
	<div class = "input-group space">
	<div class="input-group-addon">
	<span class="glyphicon glyphicon-certificate"></span> 
	</div>
	<input type="number" class="form-control" name="date" placeholder="Non-Member price-optional"/>
	</div>
	</div>
	
<!--Button-->	
	
	<div style = "width:300px" class="form-group space">
	
	<input type="submit" value="Add" class="btn btn-danger" name="Add"/>
	</div>
	
	</form>
	</div>
	
	<!-- form end-->
	</div>
	<!--<div class="modal-footer">
	<button class="btn btn-danger" data-dismiss="modal" style="float:right">Close</button>
	
	
	 </div>
	 -->
	 </div>
	
	 </div>
	 </div>
	 </div>

	
	<!--SIGN UP MODAL END-->
	
	
	
	
	 
	 <!--put verything in container for html-->
	
	<div class="container">
	
	
	</div>
	
	<div class="navbar navbar-default navbar-fixed-bottom">
  <div class="container">
    <div class="navbar-header">
      
      <a class="navbar-brand" href="#">EVENT HOME PAGE</a>
    </div>
   
  </div>
</div>
 

	<!-- Footer -->
    
	 <?php
	
		
		if($login_session!=""){
	if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$name = $_POST['name'];
	$organizer = $_POST['organizer'];
	$venue = $_POST['venue'];
	$description = $_POST['description'];
	$date = $_POST['date'];
	$m_price = $_POST['m_price'];
	$nm_price = $_POST['nm_price'];
	if($name!=""){
	mysqli_query($connection, "INSERT INTO event (username, name, description, venue, organizer, date_created,m_price,nm_price ) VALUES
		('$login_session', '$name','$description', '$venue', '$organizer', '$date','$m_price','$nm_price')");
	}
}
	}
	?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    
		
    </body>
</html>