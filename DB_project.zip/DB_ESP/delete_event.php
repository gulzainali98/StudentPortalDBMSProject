<?php 
include('lock.php');
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //echo "<i>hello</i>";
$url = $_POST['event_id'] ;
mysqli_query($connection, "DELETE FROM event WHERE username = '$login_session' AND event_id = '$url'");
}
?>