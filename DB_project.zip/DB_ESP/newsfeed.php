<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
     <style>
.User {
    border-radius: 25px;
    border: 5px solid #333333;
    position: relative;
    width: 300px;
    left: 150px;
    overflow: hidden;
    background: #8c8c8c;
    word-wrap: break-word

}
.name{
  color: #000000;
}
.description{
  color: black;
}
body
{
background: #404040; 
}
</style>

        <meta charset="UTF-8">
        <title>Lost and Found News Feed</title>
    </head>
    <body>
        <?php
        $dbhost = '127.9.145.130';
    $dbuser = 'adminqzM2lPc';
    $dbpass = 'Bh5Y2QNXQCrS';
    $db = 'nustportal';


    // Connect Database
    $conn = mysqli_connect($dbhost,$dbuser,$dbpass,$db) or die (mysql_error());
    $sql = 'select * from item;';
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
        $username = $row['username'];
        $description=$row['description'];
        $location=$row['location'];
       
        echo "<div class='User'>
        <h3 class='name'>$username</h3>
                <p class='description'><p>Location: $location</p>$description</p>
                </div><p></p>";
        
    }
        ?>
    </body>
</html>
