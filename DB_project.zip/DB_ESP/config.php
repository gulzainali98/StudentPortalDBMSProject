<?php
$hostname = "127.9.145.130";
$user = "adminqzM2lPc";
$password = "Bh5Y2QNXQCrS";
$database = "nustportal";
$connection = mysqli_connect($hostname, $user, $password, $database);


if(!$connection){
	
	echo "Connection Error";
	 
	
	
}


mysqli_select_db( $connection, $database);

?>
<!-->