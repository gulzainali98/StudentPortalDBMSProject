<?php

include ('lock.php');

	if($POST['edit']){
		
		$sentid = $_POST['edit_id'];
		
	}
	else if($POST['Add'])
{   

	$name = $_POST['name'];
	$organizer = $_POST['organizer'];
	$venue = $_POST['venue'];
	$description = $_POST['description'];
	$date = $_POST['date'];
	$m_price = $_POST['m_price'];
	$nm_price = $_POST['nm_price'];

	mysqli_query($connection, "UPDATE event set name = '$name', description = '$description', 
	venue = '$venue', organizer = '$organizer', date_created = '$date',
	m_price = '$m_price' ,nm_price = '$nm_price' WHERE event_id = '$sentid'");
	
	
}

	
	?>
	
	